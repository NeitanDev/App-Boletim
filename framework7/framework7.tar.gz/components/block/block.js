export default {
  name: 'block',
};
