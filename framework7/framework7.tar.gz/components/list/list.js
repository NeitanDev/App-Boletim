export default {
  name: 'list',
};
